<?php 

class Shoppingcart extends CI_Controller{


    public function index(){
       
        $this->load->view('cart_view');

    }

    public function complete(){
        $this->load->view('complete_view');
    }

    public function add(){

        if($_POST){

            $urunid    = $this->input->post('urun_id');
            $urunadet  = $this->input->post('urun_adet');

            if($urunadet > 0){

                $varmi     = $this->common_model->tekurun(['urunid' => $urunid],'urunler');
                if($varmi){

                    $veri = array(
                        "id" => $varmi->urunid,
                        "name" => $varmi->urunadi,
                        "qty" => $urunadet,
                        "price" => $varmi->urunfiyat
                    );

                    print_r($veri);
                    $this->cart->insert($veri);
                   
                }else{
                    'yok';
                }

            }else{
                echo 'adetbelirtin';
            }

        }

    }

    public function update(){

        if($_POST){

            $urunid    = $this->input->post('urun_id');
            $urunadet  = $this->input->post('urun_adet');

            if($urunadet > 0){

               

                $veri = array(
                    "rowid" => $urunid,
                    "qty"   => $urunadet
                );

                $this->cart->update($veri);
                   
               

            }else{
                echo 'adetbelirtin';
            }

        }

    }

    public function remove($id){
        
        if(!$id){
            redirect(base_url());
        }

        $veri = array(
            'rowid' => $id,
            'qty'   => 0
        );
        $this->cart->update($veri);
        redirect(base_url('shoppingcart'));

    }

    public function emptycart(){
        $this->cart->destroy();
        redirect(base_url());
    }

}

?>