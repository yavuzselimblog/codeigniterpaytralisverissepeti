<?php 

class Common_model extends CI_Model{

    public function tumurunler($tablo){
        return $this->db->get($tablo)->result();
    }

    public function tekurun($sutun,$tablo){
        return $this->db->where($sutun)->get($tablo)->row();
    }

    public function ekle($tablo,$veri){
        return $this->db->insert($tablo,$veri);
    }

    public function guncelle($sart,$tablo,$veri){
        return $this->db->where($sart)->update($tablo,$veri);
    }

}

?>