-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 08 Mar 2022, 08:21:05
-- Sunucu sürümü: 10.4.17-MariaDB
-- PHP Sürümü: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `codeignitersepet`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `siparisler`
--

CREATE TABLE `siparisler` (
  `id` int(11) NOT NULL,
  `isim` varchar(200) NOT NULL,
  `tel` varchar(200) NOT NULL,
  `eposta` varchar(200) NOT NULL,
  `adres` text NOT NULL,
  `toplam` double(15,2) NOT NULL,
  `tarih` timestamp NOT NULL DEFAULT current_timestamp(),
  `durum` tinyint(1) NOT NULL DEFAULT 2,
  `sipariskodu` varchar(200) NOT NULL,
  `hatakodu` varchar(300) DEFAULT NULL,
  `hatamesaj` text DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `siparisler`
--

INSERT INTO `siparisler` (`id`, `isim`, `tel`, `eposta`, `adres`, `toplam`, `tarih`, `durum`, `sipariskodu`, `hatakodu`, `hatamesaj`) VALUES
(4, 'selim', '123', 'selim@wc.n', '123', 67500.00, '2022-03-07 16:32:17', 3, '622633918ac43', NULL, NULL),
(5, 'selim', '123', 'selim@w.cn', 'istanbul', 22500.00, '2022-03-07 16:42:48', 2, '622636086e612', NULL, NULL),
(6, 'selim', '123', 'selim@w.cn', 'istanbul beşiktaş', 27500.00, '2022-03-07 16:45:25', 2, '622636a51bc27', NULL, NULL);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `urunler`
--

CREATE TABLE `urunler` (
  `urunid` int(11) NOT NULL,
  `urunadi` varchar(200) NOT NULL,
  `urunfiyat` double(15,2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `urunler`
--

INSERT INTO `urunler` (`urunid`, `urunadi`, `urunfiyat`) VALUES
(1, 'Lenovo V15', 2500.00),
(2, 'Asus', 4500.00),
(3, 'HP', 500.00),
(4, 'Monster', 6500.00);

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `siparisler`
--
ALTER TABLE `siparisler`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `urunler`
--
ALTER TABLE `urunler`
  ADD PRIMARY KEY (`urunid`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `siparisler`
--
ALTER TABLE `siparisler`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Tablo için AUTO_INCREMENT değeri `urunler`
--
ALTER TABLE `urunler`
  MODIFY `urunid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
